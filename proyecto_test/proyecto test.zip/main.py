




from clase_game import Game 


if __name__ == "__main__":
    juego = Game()
    juego.correr_nivel("nivel_1")
    




